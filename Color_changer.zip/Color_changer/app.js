toggle = document.querySelector(".lever").addEventListener("click", 
function colorChange() {
  document.body.style.backgroundColor = "black";
})


